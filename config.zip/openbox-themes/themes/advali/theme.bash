# ------------------------------------------------------------------------------
# Copyright (C) 2020-2023 Aditya Shakya <adi1090x@gmail.com>
#
# Catppuccin Mocha Theme
# ------------------------------------------------------------------------------

# Colors
background='#1E1E2E'
foreground='#CDD6F4'
color0='#45475A'
color1='#F38BA8'
color2='#A6E3A1'
color3='#F9E2AF'
color4='#89B4FA'
color5='#F5C2E7'
color6='#94E2D5'
color7='#BAC2DE'
color8='#585B70'
color9='#F38BA8'
color10='#A6E3A1'
color11='#F9E2AF'
color12='#89B4FA'
color13='#F5C2E7'
color14='#94E2D5'
color15='#A6ADC8'

accent='#DE898E'
light_value='0.08'
dark_value='0.30'

# Wallpaper
wdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
wallpaper="$wdir/wallpaper"

# Polybar
polybar_font='JetBrains Mono:size=10;3'

# Rofi
rofi_font='Iosevka 11'
rofi_icon='Papirus-Apps'

# Terminal
terminal_font_name='JetBrainsMono Nerd Font'
terminal_font_size='10'

# Geany
geany_colors='catppuccin-mocha.conf'
geany_font='JetBrains Mono 10'

# Appearance
gtk_font='Noto Sans 10'
#gtk_theme='Catppuccin-Mocha'
gtk_theme='Cyberpunk'
icon_theme='Luv-Folders-Dark'
icon_theme='Zafiro-Yellow'
cursor_theme='Sweet'

# Openbox
#ob_theme='Catppuccin-Mocha'
ob_theme='Dracula'
ob_layout='NLIMC'
ob_font='JetBrains Mono'
ob_font_size='10'
ob_menu='menu-glyphs.xml'
ob_margin_t='48'
ob_margin_b='10'
ob_margin_l='10'
ob_margin_r='10'

# Dunst
dunst_width='300'
dunst_height='80'
dunst_offset='20x58'
dunst_origin='top-right'
dunst_font='JetBrains Mono 10'
dunst_border='2'
dunst_separator='2'

# Plank
plank_hmode='intelligent'
plank_offset='0'
plank_position='bottom'
#plank_theme='Transparent'
plank_theme='Gtk+'
plank_icon_size='60'
plank_zoom_percent='120'

# Picom
picom_backend='glx'
picom_corner='0'
picom_shadow_r='14'
picom_shadow_o='0.30'
picom_shadow_x='-12'
picom_shadow_y='-12'
picom_blur_method='none'
picom_blur_strength='0'
